package org.acme.test;

public class MyClass1 {

}
